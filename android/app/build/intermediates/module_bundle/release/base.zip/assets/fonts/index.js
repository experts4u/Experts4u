export default {
  PoppinsBlack: 'Poppins-Black',
  PoppinsBold: 'Poppins-Bold',
  PoppinsExtraBold: 'Poppins-ExtraBold',
  PoppinsExtraLight: 'Poppins-ExtraLight',
  PoppinsMedium: 'Poppins-Medium',
  PoppinsRegular: 'Poppins-Regular',
  PoppinsItalic: 'Poppins-Italic',
};
